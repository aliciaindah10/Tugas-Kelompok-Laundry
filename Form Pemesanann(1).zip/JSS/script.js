(function () {
  'use strict';

  var PRICE_PER_KG = 14000;
  var DISCOUNT_RATE = 0.10;
  var SHIPPING_ORIGINAL = 10000;

  var state = {
    kg: 4.0,
    items: [
      { name: 'Kemeja Putih Formal', qty: 2, luntur: false },
      { name: 'Batik Tulis Sutra', qty: 1, luntur: true },
      { name: 'Kaos Polos Hitam & Abu', qty: 3, luntur: false },
      { name: 'Celana Jeans Raw Indigo', qty: 1, luntur: true }
    ],
    photos: 1
  };

  function rp(n) {
    return 'Rp ' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  }
  function $(id) { return document.getElementById(id); }
  function totalPcs() {
    return state.items.reduce(function (a, b) { return a + b.qty; }, 0);
  }

  /* ---------- Perhitungan ---------- */
  function recalc() {
    var subtotal = state.kg * PRICE_PER_KG;
    var spot = 0, hanger = 0;

    document.querySelectorAll('.addon').forEach(function (a) {
      var checked = a.classList.contains('checked');
      if (a.dataset.key === 'spot' && checked) spot = Number(a.dataset.price);
      if (a.dataset.key === 'hanger' && checked) hanger = Number(a.dataset.price) * totalPcs();
    });

    var discount = subtotal * DISCOUNT_RATE;
    var total = subtotal + spot + hanger - discount;
    var strike = subtotal + spot + hanger;

    $('lblSubtotal').textContent = 'Subtotal Cucian (' + state.kg.toFixed(1) + ' Kg × Rp 14.000)';
    $('vSubtotal').textContent = rp(subtotal);
    $('rowSpot').hidden = spot === 0;
    $('vSpot').textContent = rp(spot);
    $('rowHanger').hidden = hanger === 0;
    $('vHanger').textContent = rp(hanger);
    $('vDisc').textContent = '-' + rp(discount);
    $('vTotal').textContent = rp(total);
    $('vSaveSmall').textContent = 'Hemat ' + rp(discount);
    $('sbTotal').textContent = rp(total);
    $('sbStrike').textContent = rp(strike);
    $('sbSave').textContent = 'Hemat ' + rp(discount);
  }

  /* ---------- Tab layanan ---------- */
  var tabs = document.querySelectorAll('#serviceTabs .tab');
  tabs.forEach(function (t) {
    t.addEventListener('click', function () {
      tabs.forEach(function (x) {
        x.classList.remove('active');
        x.querySelector('.radio').classList.remove('on');
      });
      t.classList.add('active');
      t.querySelector('.radio').classList.add('on');
    });
  });

  /* ---------- Berat ---------- */
  $('kgMinus').addEventListener('click', function () {
    state.kg = Math.max(1, Math.round((state.kg - 0.5) * 10) / 10);
    $('kgInput').value = state.kg.toFixed(1);
    recalc();
  });
  $('kgPlus').addEventListener('click', function () {
    state.kg = Math.min(30, Math.round((state.kg + 0.5) * 10) / 10);
    $('kgInput').value = state.kg.toFixed(1);
    recalc();
  });

  /* ---------- Add-on ---------- */
  document.querySelectorAll('.addon').forEach(function (a) {
    a.addEventListener('click', function (e) {
      e.preventDefault();
      a.classList.toggle('checked');
      a.querySelector('input').checked = a.classList.contains('checked');
      recalc();
    });
  });

  /* ---------- Opsi pengambilan ---------- */
  var opts = document.querySelectorAll('#deliveryOpts .opt');
  opts.forEach(function (o) {
    o.addEventListener('click', function (e) {
      e.preventDefault();
      opts.forEach(function (x) {
        x.classList.remove('selected');
        x.querySelector('.radio').classList.remove('on');
      });
      o.classList.add('selected');
      o.querySelector('.radio').classList.add('on');
      var kurir = o.dataset.opt === 'kurir';
      ['addrGrid', 'slotLabel', 'slots'].forEach(function (id) { $(id).hidden = !kurir; });
    });
  });

  /* ---------- Slot ---------- */
  var slots = document.querySelectorAll('#slots .slot');
  slots.forEach(function (s) {
    s.addEventListener('click', function () {
      slots.forEach(function (x) { x.classList.remove('active'); });
      s.classList.add('active');
    });
  });

  /* ---------- Daftar pakaian ---------- */
  var SHIRT = '<svg class="i"><use href="#i-shirt"/></svg>';
  var DROP = '<svg class="i"><use href="#i-drop"/></svg>';

  function esc(s) {
    return s.replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function renderItems() {
    var wrap = $('items');
    wrap.innerHTML = '';
    state.items.forEach(function (it, idx) {
      var el = document.createElement('div');
      el.className = 'item' + (it.luntur ? ' warn' : '');
      el.innerHTML =
        (it.luntur ? DROP : SHIRT) +
        '<span class="nm">' + esc(it.name) + ' (' + it.qty + ' pcs)' +
        (it.luntur ? ' <span class="lt">• Luntur</span>' : '') + '</span>' +
        '<span class="sp"></span>' +
        '<span class="st ' + (it.luntur ? 'bad' : 'ok') + '">' +
        (it.luntur ? 'Rawan Luntur (Dipisah)' : 'Warna Aman') + '</span>' +
        '<button type="button" class="rm" data-i="' + idx + '" aria-label="Hapus"><svg><use href="#i-x"/></svg></button>';
      wrap.appendChild(el);
    });
    $('itemsTitle').textContent = 'Daftar Pakaian Terdata (' + totalPcs() + ' Pcs)';
    recalc();
  }

  $('items').addEventListener('click', function (e) {
    var b = e.target.closest('.rm');
    if (!b) return;
    state.items.splice(Number(b.dataset.i), 1);
    renderItems();
  });

  function addItem() {
    var input = $('newItem');
    var name = input.value.trim();
    if (!name) { input.focus(); return; }
    state.items.push({ name: name, qty: 1, luntur: $('newLuntur').checked });
    input.value = '';
    $('newLuntur').checked = false;
    renderItems();
  }
  $('addItemBtn').addEventListener('click', addItem);
  $('newItem').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') { e.preventDefault(); addItem(); }
  });

  /* ---------- Foto ---------- */
  function updatePhotoCount() {
    var n = document.querySelectorAll('#uploadRow .thumb').length;
    state.photos = n;
    $('photoCount').textContent = n;
  }

  $('uploadRow').addEventListener('click', function (e) {
    var x = e.target.closest('.thumb-x');
    if (x) {
      x.closest('.thumb').remove();
      updatePhotoCount();
    }
  });

  function addThumb(src, name) {
    if (document.querySelectorAll('#uploadRow .thumb').length >= 3) {
      alert('Maksimal 3 foto.');
      return;
    }
    var t = document.createElement('div');
    t.className = 'thumb';
    t.innerHTML =
      '<div class="thumb-img"' + (src ? ' style="background:url(' + src + ') center/cover"' : '') + '></div>' +
      '<button type="button" class="thumb-x" aria-label="Hapus"><svg><use href="#i-x"/></svg></button>' +
      '<div class="thumb-cap"><b>' + esc(name || 'Foto Baru') + '</b>' +
      '<small><svg><use href="#i-check-circle"/></svg>Terunggah • Bukti Noda Awal</small></div>';
    $('uploadRow').insertBefore(t, $('addPhoto'));
    updatePhotoCount();
  }

  function handleFiles(files) {
    Array.prototype.forEach.call(files, function (f) {
      if (!/^image\/(jpeg|png)$/.test(f.type)) return;
      if (f.size > 5 * 1024 * 1024) { alert('Ukuran foto maksimal 5MB.'); return; }
      var r = new FileReader();
      r.onload = function (ev) { addThumb(ev.target.result, f.name.replace(/\.[^.]+$/, '')); };
      r.readAsDataURL(f);
    });
  }

  $('fileInput').addEventListener('change', function (e) {
    handleFiles(e.target.files);
    e.target.value = '';
  });
  $('addPhoto').addEventListener('click', function () { $('fileInput').click(); });

  var dz = document.querySelector('.dropzone');
  ['dragover', 'dragenter'].forEach(function (ev) {
    dz.addEventListener(ev, function (e) { e.preventDefault(); dz.style.background = '#eef5fc'; });
  });
  ['dragleave', 'drop'].forEach(function (ev) {
    dz.addEventListener(ev, function (e) { e.preventDefault(); dz.style.background = '#fff'; });
  });
  dz.addEventListener('drop', function (e) { handleFiles(e.dataTransfer.files); });

  /* ---------- Metode pembayaran ---------- */
  var pays = document.querySelectorAll('#payOpts .pay-opt');
  pays.forEach(function (p) {
    p.addEventListener('click', function (e) {
      e.preventDefault();
      pays.forEach(function (x) {
        x.classList.remove('selected');
        x.querySelector('.radio').classList.remove('on');
      });
      p.classList.add('selected');
      p.querySelector('.radio').classList.add('on');
      $('sbMethod').textContent = p.dataset.method;
      $('sbFree').style.display = p.dataset.free ? '' : 'none';
    });
  });

  /* ---------- Konfirmasi ---------- */
  $('confirmBtn').addEventListener('click', function () {
    var wa = $('wa'), box = wa.parentNode, alamat = $('alamat');
    var kurir = document.querySelector('#deliveryOpts .opt.selected').dataset.opt === 'kurir';
    box.classList.remove('invalid'); alamat.classList.remove('invalid');
    if (!/^[0-9+\-\s]{9,16}$/.test(wa.value.trim())) {
      box.classList.add('invalid'); wa.focus(); alert('Nomor WhatsApp belum valid.'); return;
    }
    if (kurir && !alamat.value.trim()) {
      alamat.classList.add('invalid'); alamat.focus(); alert('Alamat penjemputan wajib diisi.'); return;
    }
    if (!state.items.length) { alert('Tambahkan minimal 1 item pakaian.'); return; }
    alert('Pesanan dikonfirmasi!\nMetode: ' + $('sbMethod').textContent + '\nTotal: ' + $('sbTotal').textContent);
  });

  /* init */
  renderItems();
})();
