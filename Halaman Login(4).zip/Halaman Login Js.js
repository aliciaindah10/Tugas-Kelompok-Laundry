const $ = (s) => document.querySelector(s);
const user = $('#user'), pass = $('#pass'), alertBox = $('#alert'), submit = $('#submit');
const roles = [...document.querySelectorAll('.role')];
const tabs = [...document.querySelectorAll('.tab')];

function showAlert(msg, type) {
  alertBox.textContent = msg;
  alertBox.className = 'alert show ' + type;
}

function setRole(btn) {
  roles.forEach(r => r.classList.toggle('active', r === btn));
  user.value = btn.dataset.id;
  pass.value = 'demo12345678';
  setMode(btn.dataset.mode, false);
  alertBox.className = 'alert';
}

function setMode(mode, resetRole = true) {
  tabs.forEach(t => t.classList.toggle('active', t.dataset.mode === mode));
  if (resetRole) {
    const first = roles.find(r => r.dataset.mode === mode);
    if (first) setRole(first);
  }
}

roles.forEach(r => r.addEventListener('click', () => setRole(r)));
tabs.forEach(t => t.addEventListener('click', () => setMode(t.dataset.mode)));
$('#simulasi').addEventListener('click', (e) => { e.preventDefault(); setRole(roles[0]); });

$('#toggle').addEventListener('click', () => {
  const hidden = pass.type === 'password';
  pass.type = hidden ? 'text' : 'password';
  $('#toggle').setAttribute('aria-label', hidden ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi');
});

$('#form').addEventListener('submit', (e) => {
  e.preventDefault();
  if (!user.value.trim() || !pass.value) {
    showAlert('Isi email/No. WhatsApp/username dan kata sandi terlebih dahulu.', 'err');
    return;
  }
  submit.disabled = true;
  submit.firstChild.textContent = 'Memproses... ';
  // TODO: ganti dengan request ke backend Anda, contoh:
  // fetch('/api/login', { method: 'POST', headers: {'Content-Type':'application/json'},
  //   body: JSON.stringify({ identifier: user.value, password: pass.value, remember: $('#remember').checked }) })
  setTimeout(() => {
    submit.disabled = false;
    submit.firstChild.textContent = 'Masuk Sekarang ';
    showAlert('Berhasil masuk (simulasi). Hubungkan ke backend untuk login sungguhan.', 'ok');
  }, 900);
});

$('#otp').addEventListener('click', () => {
  if (!user.value.trim()) { showAlert('Masukkan No. WhatsApp Anda terlebih dahulu.', 'err'); user.focus(); return; }
  showAlert('Kode OTP akan dikirim ke WhatsApp ' + user.value + ' (simulasi).', 'ok');
});